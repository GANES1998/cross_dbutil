module.exports = {
  INNER_JOIN = 1;
  LEFT_JOIN = 2;
  RIGHT_JOIN = 3;
  OUTER_JOIN = 4 ;
};
